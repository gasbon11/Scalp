CREATE TABLE `marketMetadata` (
	`id` int AUTO_INCREMENT NOT NULL,
	`exchange` varchar(50) NOT NULL,
	`marketMode` varchar(10) NOT NULL,
	`symbol` varchar(100) NOT NULL,
	`baseAsset` varchar(50) NOT NULL,
	`quoteAsset` varchar(50) NOT NULL,
	`pricePrecision` int NOT NULL,
	`amountPrecision` int NOT NULL,
	`minPrice` varchar(100),
	`maxPrice` varchar(100),
	`minAmount` varchar(100),
	`maxAmount` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `marketMetadata_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userPreferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`language` varchar(10) NOT NULL DEFAULT 'en',
	`defaultExchange` varchar(50) NOT NULL DEFAULT 'binance',
	`defaultMarketMode` varchar(10) NOT NULL DEFAULT 'spot',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userPreferences_id` PRIMARY KEY(`id`)
);
