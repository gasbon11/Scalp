import ccxt from 'ccxt';

export type ExchangeName = 'okx' | 'mexc' | 'bitget';
export type MarketMode = 'spot' | 'futures';

interface MarketInfo {
  symbol: string;
  baseAsset: string;
  quoteAsset: string;
  pricePrecision: number;
  amountPrecision: number;
  minPrice?: string;
  maxPrice?: string;
  minAmount?: string;
  maxAmount?: string;
}

interface OHLCV {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface CandleData {
  timeframe: string;
  candles: OHLCV[];
}

// Initialize exchanges — Binance kaldırıldı
const spotExchanges: Record<ExchangeName, any> = {
  okx: new ccxt.okx({ enableRateLimit: true }),
  mexc: new ccxt.mexc({ enableRateLimit: true, timeout: 10000 }),
  bitget: new ccxt.bitget({ enableRateLimit: true }),
};

// Futures exchanges (Binance kaldırıldı)
const futuresExchanges: Record<ExchangeName, any> = {
  okx: new ccxt.okx({ enableRateLimit: true }),
  mexc: new ccxt.mexc({ enableRateLimit: true, timeout: 10000 }),
  bitget: new ccxt.bitget({ enableRateLimit: true }),
};

// Market cache — MEXC performans iyileştirmesi
const marketCache: Record<string, { data: MarketInfo[]; timestamp: number }> = {};
const CACHE_TTL = 10 * 60 * 1000; // 10 dakika
let mexcMarketsPreloading = false;
let mexcMarketsPreloaded = false;

// MEXC piyasalarını arka planda önceden yükle
async function preloadMexcMarkets() {
  if (mexcMarketsPreloading || mexcMarketsPreloaded) return;
  mexcMarketsPreloading = true;
  try {
    await fetchAllMarkets('mexc', 'futures');
    mexcMarketsPreloaded = true;
  } catch (error) {
    console.warn('Failed to preload MEXC markets:', error);
  } finally {
    mexcMarketsPreloading = false;
  }
}

// Sunucu başladığında MEXC piyasalarını yükle
setTimeout(() => preloadMexcMarkets(), 1000);

/**
 * Get exchange instance based on mode
 */
export function getExchange(exchangeName: ExchangeName, marketMode: MarketMode = 'futures'): any {
  const map = marketMode === 'futures' ? futuresExchanges : spotExchanges;
  const exchange = map[exchangeName];
  if (!exchange) {
    throw new Error(`Exchange ${exchangeName} not supported`);
  }
  return exchange;
}

/**
 * Fetch all markets from exchange (MEXC için cache ile optimize)
 */
export async function fetchAllMarkets(
  exchangeName: ExchangeName,
  marketMode: MarketMode
): Promise<MarketInfo[]> {
  try {
    const cacheKey = `${exchangeName}-${marketMode}`;
    const now = Date.now();
    
    // MEXC için cache kontrol et
    if (exchangeName === 'mexc' && marketCache[cacheKey]) {
      const cached = marketCache[cacheKey];
      if (now - cached.timestamp < CACHE_TTL) {
        return cached.data;
      }
    }
    
    const exchange = getExchange(exchangeName, marketMode);

    // Load markets to ensure fresh data
    await exchange.loadMarkets();

    // Fetch markets with proper filtering
    const markets = await exchange.fetchMarkets();

    // Cache'e kaydet (MEXC için)
    const filtered = markets.filter((market: any) => {
      if (marketMode === 'spot') {
        return market.spot === true && market.type === 'spot';
      } else if (marketMode === 'futures') {
        // Binanceusdm zaten sadece futures döndürür; diğer borsalar için filtrele
        return (
          market.future === true ||
          market.swap === true ||
          market.type === 'future' ||
          market.type === 'swap' ||
          market.linear === true
        );
      }
      return false;
    });

    const result = filtered.map((market: any) => ({
      symbol: market.symbol,
      baseAsset: market.base,
      quoteAsset: market.quote,
      pricePrecision: market.precision?.price || 8,
      amountPrecision: market.precision?.amount || 8,
      minPrice: market.limits?.price?.min?.toString(),
      maxPrice: market.limits?.price?.max?.toString(),
      minAmount: market.limits?.amount?.min?.toString(),
      maxAmount: market.limits?.amount?.max?.toString(),
    }));
    
    // MEXC için cache'e kaydet
    if (exchangeName === 'mexc') {
      marketCache[cacheKey] = {
        data: result,
        timestamp: Date.now(),
      };
    }
    
    return result;
  } catch (error) {
    console.error(`Error fetching markets from ${exchangeName}:`, error);
    throw error;
  }
}

/**
 * Fetch OHLCV data for a symbol (live data, no caching)
 */
export async function fetchOHLCV(
  exchangeName: ExchangeName,
  symbol: string,
  timeframe: string,
  limit: number = 100,
  marketMode: MarketMode = 'futures'
): Promise<OHLCV[]> {
  try {
    const exchange = getExchange(exchangeName, marketMode);

    // MEXC icin timeout ile sarili
    let fetchPromise = exchange.fetchOHLCV(symbol, timeframe, undefined, limit);
    if (exchangeName === 'mexc') {
      fetchPromise = Promise.race([
        fetchPromise,
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('OHLCV fetch timeout')), 7000)
        )
      ]);
    }

    const ohlcv = await fetchPromise;

    return ohlcv.map(([timestamp, open, high, low, close, volume]: any[]) => ({
      timestamp,
      open,
      high,
      low,
      close,
      volume,
    }));
  } catch (error) {
    console.error(`Error fetching OHLCV for ${symbol} on ${exchangeName}:`, error);
    throw error;
  }
}

/**
 * Fetch multiple timeframes for a symbol
 * 15m de dahil
 */
export async function fetchMultiTimeframeOHLCV(
  exchangeName: ExchangeName,
  symbol: string,
  timeframes: string[] = ['1m', '3m', '5m', '15m'],
  marketMode: MarketMode = 'futures'
): Promise<CandleData[]> {
  try {
    const results = await Promise.all(
      timeframes.map(async (timeframe) => {
        const candles = await fetchOHLCV(exchangeName, symbol, timeframe, 100, marketMode);
        return {
          timeframe,
          candles,
        };
      })
    );
    return results;
  } catch (error) {
    console.error(`Error fetching multi-timeframe data for ${symbol}:`, error);
    throw error;
  }
}

/**
 * Search markets by symbol pattern
 */
export async function searchMarkets(
  exchangeName: ExchangeName,
  marketMode: MarketMode,
  searchTerm: string
): Promise<MarketInfo[]> {
  try {
    const markets = await fetchAllMarkets(exchangeName, marketMode);
    const term = searchTerm.toUpperCase();

    return markets
      .filter(
        (market) =>
          market.symbol.includes(term) ||
          market.baseAsset.includes(term) ||
          market.quoteAsset.includes(term)
      )
      .sort((a, b) => {
        // Prioritize exact matches and popular assets
        const aExact = a.symbol.startsWith(term) ? 0 : 1;
        const bExact = b.symbol.startsWith(term) ? 0 : 1;
        if (aExact !== bExact) return aExact - bExact;

        // Prioritize USDT pairs
        const aUsdt = a.quoteAsset === 'USDT' ? 0 : 1;
        const bUsdt = b.quoteAsset === 'USDT' ? 0 : 1;
        if (aUsdt !== bUsdt) return aUsdt - bUsdt;

        return a.symbol.localeCompare(b.symbol);
      })
      .slice(0, 50); // Return top 50 results
  } catch (error) {
    console.error(`Error searching markets on ${exchangeName}:`, error);
    throw error;
  }
}

/**
 * Get ticker data (current price) — futures baz alır
 */
export async function fetchTicker(
  exchangeName: ExchangeName,
  symbol: string,
  marketMode: MarketMode = 'futures'
): Promise<any> {
  try {
    const exchange = getExchange(exchangeName, marketMode);
    // MEXC için timeout ile sarıl
    if (exchangeName === 'mexc') {
      return await Promise.race([
        exchange.fetchTicker(symbol),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Ticker fetch timeout')), 8000)
        )
      ]);
    }
    return await exchange.fetchTicker(symbol);
  } catch (error) {
    console.error(`Error fetching ticker for ${symbol} on ${exchangeName}:`, error);
    throw error;
  }
}
