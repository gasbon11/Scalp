import { EMA, RSI, ATR } from 'technicalindicators';

interface OHLCV {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface TechnicalSignal {
  timeframe: string;
  vwap?: number;
  ema9?: number;
  ema21?: number;
  rsi14?: number;
  atr?: number;
  bias: 'long' | 'short' | 'neutral';
  strength: 'strong' | 'weak';
}

// 15m bağımsız trend modülü sonucu
interface TrendSignal15m {
  trend: 'strong_long' | 'strong_short' | 'neutral';
  diffPercent: number;
  open3CandlesAgo: number;
  currentClose: number;
}

interface DecisionResult {
  decision: 'LONG' | 'SHORT' | 'WAIT';
  signals: {
    '5m': TechnicalSignal;
    '3m': TechnicalSignal;
    '1m': TechnicalSignal;
  };
  trend15m?: TrendSignal15m;
  tpSl?: {
    entry: number;
    sl: number;
    tp1: number;
    tp2: number;
    riskReward1: string;
    riskReward2: string;
  };
}

/**
 * Calculate VWAP (Volume Weighted Average Price)
 */
export function calculateVWAP(candles: OHLCV[]): number {
  if (candles.length === 0) return 0;

  let cumulativeTypicalPriceVolume = 0;
  let cumulativeVolume = 0;

  for (const candle of candles) {
    const typicalPrice = (candle.high + candle.low + candle.close) / 3;
    cumulativeTypicalPriceVolume += typicalPrice * candle.volume;
    cumulativeVolume += candle.volume;
  }

  return cumulativeVolume > 0 ? cumulativeTypicalPriceVolume / cumulativeVolume : 0;
}

/**
 * Calculate EMA (Exponential Moving Average)
 */
export function calculateEMA(candles: OHLCV[], period: number): number {
  const closes = candles.map((c) => c.close);
  const emaValues = EMA.calculate({ values: closes, period });
  return emaValues.length > 0 ? emaValues[emaValues.length - 1] : 0;
}

/**
 * Calculate RSI (Relative Strength Index)
 */
export function calculateRSI(candles: OHLCV[], period: number = 14): number {
  const closes = candles.map((c) => c.close);
  const rsiValues = RSI.calculate({ values: closes, period });
  return rsiValues.length > 0 ? rsiValues[rsiValues.length - 1] : 50;
}

/**
 * Calculate ATR (Average True Range)
 */
export function calculateATR(candles: OHLCV[], period: number = 14): number {
  const high = candles.map((c) => c.high);
  const low = candles.map((c) => c.low);
  const close = candles.map((c) => c.close);

  const atrValues = ATR.calculate({ high, low, close, period });
  return atrValues.length > 0 ? atrValues[atrValues.length - 1] : 0;
}

/**
 * ===== BAĞIMSIZ 15M TREND MODÜLÜ =====
 * Ana 1-3-5m analizinden tamamen izole çalışır.
 * Sadece sinyal (LONG/SHORT) oluştuğu anda tetiklenir.
 * Son 3 mumun ilk açılışı ile güncel kapanış arasındaki farkı hesaplar.
 * Fark >= %0.15 → strong_long, <= -%0.15 → strong_short
 */
export function analyze15mTrend(candles15m: OHLCV[]): TrendSignal15m {
  if (candles15m.length < 3) {
    return {
      trend: 'neutral',
      diffPercent: 0,
      open3CandlesAgo: 0,
      currentClose: 0,
    };
  }

  // Son 3 mum: [n-3, n-2, n-1] (n-1 = en güncel)
  const last3 = candles15m.slice(-3);
  const open3CandlesAgo = last3[0].open;
  const currentClose = last3[last3.length - 1].close;

  const diffPercent = ((currentClose - open3CandlesAgo) / open3CandlesAgo) * 100;

  let trend: TrendSignal15m['trend'] = 'neutral';
  if (diffPercent >= 0.15) {
    trend = 'strong_long';
  } else if (diffPercent <= -0.15) {
    trend = 'strong_short';
  }

  return {
    trend,
    diffPercent,
    open3CandlesAgo,
    currentClose,
  };
}

/**
 * Analyze 5-minute timeframe (VWAP bias)
 */
export function analyze5m(candles: OHLCV[]): TechnicalSignal {
  if (candles.length < 20) {
    return {
      timeframe: '5m',
      bias: 'neutral',
      strength: 'weak',
    };
  }

  const currentPrice = candles[candles.length - 1].close;
  const vwap = calculateVWAP(candles);

  const bias = currentPrice > vwap ? 'long' : currentPrice < vwap ? 'short' : 'neutral';
  const strength = Math.abs(currentPrice - vwap) / vwap > 0.01 ? 'strong' : 'weak';

  return {
    timeframe: '5m',
    vwap,
    bias,
    strength,
  };
}

/**
 * Analyze 3-minute timeframe (EMA + RSI momentum)
 */
export function analyze3m(candles: OHLCV[]): TechnicalSignal {
  if (candles.length < 21) {
    return {
      timeframe: '3m',
      bias: 'neutral',
      strength: 'weak',
    };
  }

  const ema9 = calculateEMA(candles, 9);
  const ema21 = calculateEMA(candles, 21);
  const rsi = calculateRSI(candles, 14);

  let bias: 'long' | 'short' | 'neutral' = 'neutral';
  let strength: 'strong' | 'weak' = 'weak';

  if (ema9 > ema21 && rsi > 50) {
    bias = 'long';
    strength = rsi > 60 ? 'strong' : 'weak';
  } else if (ema9 < ema21 && rsi < 50) {
    bias = 'short';
    strength = rsi < 40 ? 'strong' : 'weak';
  }

  return {
    timeframe: '3m',
    ema9,
    ema21,
    rsi14: rsi,
    bias,
    strength,
  };
}

/**
 * Analyze 1-minute timeframe (EMA timing)
 */
export function analyze1m(candles: OHLCV[]): TechnicalSignal {
  if (candles.length < 9) {
    return {
      timeframe: '1m',
      bias: 'neutral',
      strength: 'weak',
    };
  }

  const currentPrice = candles[candles.length - 1].close;
  const ema9 = calculateEMA(candles, 9);

  const bias = currentPrice > ema9 ? 'long' : currentPrice < ema9 ? 'short' : 'neutral';
  const strength = Math.abs(currentPrice - ema9) / ema9 > 0.005 ? 'strong' : 'weak';

  return {
    timeframe: '1m',
    ema9,
    bias,
    strength,
  };
}

/**
 * TP/SL hesaplama:
 * SL: 3m son 10 mumun Swing High/Low + (1.2 * ATR[14]) emniyet payı
 * TP: Minimum 1:1.5 Risk/Reward
 * Fiyatlar tam hassasiyetle gösterilir
 */
export function calculateTPSL(
  entry: number,
  candles3m: OHLCV[],
  bias: 'long' | 'short'
): {
  sl: number;
  tp1: number;
  tp2: number;
  riskReward1: string;
  riskReward2: string;
} {
  // Son 10 mum swing high/low
  const last10 = candles3m.slice(-10);
  const swingHigh = last10.length > 0 ? Math.max(...last10.map((c) => c.high)) : entry;
  const swingLow = last10.length > 0 ? Math.min(...last10.map((c) => c.low)) : entry;

  // ATR[14] hesapla
  const atr = calculateATR(candles3m, 14);
  const atrBuffer = 1.2 * atr;

  let sl: number;
  if (bias === 'long') {
    // Long: SL = swing low - ATR buffer
    sl = swingLow - atrBuffer;
  } else {
    // Short: SL = swing high + ATR buffer
    sl = swingHigh + atrBuffer;
  }

  const riskAmount = Math.abs(entry - sl);

  // TP1: 1:1.5, TP2: 1:2.5
  let tp1: number;
  let tp2: number;
  if (bias === 'long') {
    tp1 = entry + riskAmount * 1.5;
    tp2 = entry + riskAmount * 2.5;
  } else {
    tp1 = entry - riskAmount * 1.5;
    tp2 = entry - riskAmount * 2.5;
  }

  return {
    sl,
    tp1,
    tp2,
    riskReward1: '1:1.5',
    riskReward2: '1:2.5',
  };
}

/**
 * Make trading decision based on multi-timeframe analysis
 * Ana 1-3-5m motoru — DOKUNULMAZ
 */
export function makeDecision(
  signal5m: TechnicalSignal,
  signal3m: TechnicalSignal,
  signal1m: TechnicalSignal,
  currentPrice: number,
  candles3m: OHLCV[],
  trend15m?: TrendSignal15m
): DecisionResult {
  // Check if all timeframes agree
  const allLong = signal5m.bias === 'long' && signal3m.bias === 'long' && signal1m.bias === 'long';
  const allShort =
    signal5m.bias === 'short' && signal3m.bias === 'short' && signal1m.bias === 'short';

  let decision: 'LONG' | 'SHORT' | 'WAIT' = 'WAIT';
  if (allLong) decision = 'LONG';
  else if (allShort) decision = 'SHORT';

  let tpSl: DecisionResult['tpSl'] | undefined;
  if (decision === 'LONG' || decision === 'SHORT') {
    const bias = decision === 'LONG' ? 'long' : 'short';
    const { sl, tp1, tp2, riskReward1, riskReward2 } = calculateTPSL(
      currentPrice,
      candles3m,
      bias
    );
    tpSl = {
      entry: currentPrice,
      sl,
      tp1,
      tp2,
      riskReward1,
      riskReward2,
    };
  }

  return {
    decision,
    signals: {
      '5m': signal5m,
      '3m': signal3m,
      '1m': signal1m,
    },
    trend15m,
    tpSl,
  };
}

/**
 * Comprehensive multi-timeframe analysis
 * candles15m opsiyonel — 15m trend modülü için
 */
export function analyzeMultiTimeframe(
  candles1m: OHLCV[],
  candles3m: OHLCV[],
  candles5m: OHLCV[],
  candles15m?: OHLCV[]
): DecisionResult {
  const signal1m = analyze1m(candles1m);
  const signal3m = analyze3m(candles3m);
  const signal5m = analyze5m(candles5m);

  const currentPrice = candles1m[candles1m.length - 1].close;

  // 15m bağımsız trend modülü — sadece sinyal gelince tetiklenir
  let trend15m: TrendSignal15m | undefined;
  if (candles15m && candles15m.length >= 3) {
    trend15m = analyze15mTrend(candles15m);
  }

  return makeDecision(signal5m, signal3m, signal1m, currentPrice, candles3m, trend15m);
}
