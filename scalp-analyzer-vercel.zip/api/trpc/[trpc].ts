import { createExpressMiddleware } from "@trpc/server/adapters/express";
import type { VercelRequest, VercelResponse } from "@vercel/node";
import { appRouter } from "../../server/routers";
import { createContext } from "../../server/_core/context";

const handler = createExpressMiddleware({
  router: appRouter,
  createContext: createContext as any,
});

export default function (req: VercelRequest, res: VercelResponse) {
  return handler(req as any, res as any);
}
