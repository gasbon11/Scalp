import type { VercelRequest, VercelResponse } from "@vercel/node";
import { COOKIE_NAME, ONE_YEAR_MS } from "../../shared/const";
import { sdk } from "../../server/_core/sdk";
import * as db from "../../server/db";
import { getSessionCookieOptions } from "../../server/_core/cookies";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const code = req.query["code"] as string | undefined;
  const state = req.query["state"] as string | undefined;

  if (!code || !state) {
    return res.status(400).json({ error: "code and state are required" });
  }

  try {
    const tokenResponse = await sdk.exchangeCodeForToken(code, state);
    const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);

    if (!userInfo.openId) {
      return res.status(400).json({ error: "openId missing from user info" });
    }

    await db.upsertUser({
      openId: userInfo.openId,
      name: userInfo.name ?? null,
      email: userInfo.email ?? null,
      loginMethod: "oauth",
      lastSignedIn: new Date(),
    });

    const cookieOptions = getSessionCookieOptions(req as any);
    const token = await sdk.createSessionToken({
      openId: userInfo.openId,
      expiresIn: ONE_YEAR_MS,
    });

    res.setHeader(
      "Set-Cookie",
      `${COOKIE_NAME}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${ONE_YEAR_MS / 1000}; Secure`
    );

    return res.redirect("/");
  } catch (error) {
    console.error("OAuth callback error:", error);
    return res.status(500).json({ error: "Authentication failed" });
  }
}
