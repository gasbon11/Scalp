import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'en' | 'tr';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    'app.title': 'Scalp Analyzer',
    'app.subtitle': 'Real-time Trading Signals',
    'exchange.select': 'Select Exchange',
    'exchange.binance': 'Binance',
    'exchange.okx': 'OKX',
    'exchange.mexc': 'MEXC',
    'exchange.bitget': 'Bitget',
    'market.spot': 'SPOT',
    'market.futures': 'FUTURES',
    'market.toggle': 'Market Mode',
    'search.placeholder': 'Search token (BTC, ETH, etc.)',
    'search.results': 'Search Results',
    'signal.long': 'LONG',
    'signal.short': 'SHORT',
    'signal.wait': 'WAIT',
    'signal.decision': 'Decision',
    'signal.timeframe5m': '5-Minute (VWAP)',
    'signal.timeframe3m': '3-Minute (EMA+RSI)',
    'signal.timeframe1m': '1-Minute (Timing)',
    'signal.bias': 'Bias',
    'signal.bias.long': 'LONG',
    'signal.bias.short': 'SHORT',
    'signal.neutral': 'NEUTRAL',
    'signal.strength': 'Strength',
    'signal.strong': 'Strong',
    'signal.weak': 'Weak',
    'trend15m.strong_long': 'Strong LONG',
    'trend15m.strong_short': 'Strong SHORT',
    'trend15m.neutral': 'Neutral',
    'trend15m.label': '15m Trend',
    'tp.title': 'Take Profit',
    'tp.sl': 'Stop Loss',
    'tp.entry': 'Entry',
    'tp.tp1': 'TP1 (1:1.5)',
    'tp.tp2': 'TP2 (1:2.5)',
    'tp.riskReward': 'Risk/Reward',
    'price.current': 'Current Price',
    'price.vwap': 'VWAP',
    'price.ema9': 'EMA(9)',
    'price.ema21': 'EMA(21)',
    'price.rsi': 'RSI(14)',
    'price.atr': 'ATR',
    'footer.disclaimer': 'Not financial advice.',
    'footer.risk': 'Always manage risk properly.',
    'language.toggle': 'Language',
    'loading': 'Loading...',
    'error': 'Error loading data',
    'noResults': 'No results found',
    'refresh': 'Refresh',
  },
  tr: {
    'app.title': 'Scalp Analyzer',
    'app.subtitle': 'Gerçek Zamanlı İşlem Sinyalleri',
    'exchange.select': 'Borsayı Seçin',
    'exchange.binance': 'Binance',
    'exchange.okx': 'OKX',
    'exchange.mexc': 'MEXC',
    'exchange.bitget': 'Bitget',
    'market.spot': 'SPOT',
    'market.futures': 'FUTURES',
    'market.toggle': 'Pazar Modu',
    'search.placeholder': 'Token ara (BTC, ETH, vb.)',
    'search.results': 'Arama Sonuçları',
    'signal.long': 'LONG',
    'signal.short': 'SHORT',
    'signal.wait': 'BEKLE',
    'signal.decision': 'Karar',
    'signal.timeframe5m': '5 Dakika (VWAP)',
    'signal.timeframe3m': '3 Dakika (EMA+RSI)',
    'signal.timeframe1m': '1 Dakika (Zamanlama)',
    'signal.bias': 'Yön',
    'signal.bias.long': 'LONG',
    'signal.bias.short': 'SHORT',
    'signal.neutral': 'NÖTR',
    'signal.strength': 'Güç',
    'signal.strong': 'Güçlü',
    'signal.weak': 'Zayıf',
    'trend15m.strong_long': 'Güçlü Long',
    'trend15m.strong_short': 'Güçlü Short',
    'trend15m.neutral': 'Nötr',
    'trend15m.label': '15dk Trend',
    'tp.title': 'Kâr Al',
    'tp.sl': 'Zararı Durdur',
    'tp.entry': 'Giriş',
    'tp.tp1': 'TP1 (1:1.5)',
    'tp.tp2': 'TP2 (1:2.5)',
    'tp.riskReward': 'Risk/Ödül',
    'price.current': 'Güncel Fiyat',
    'price.vwap': 'VWAP',
    'price.ema9': 'EMA(9)',
    'price.ema21': 'EMA(21)',
    'price.rsi': 'RSI(14)',
    'price.atr': 'ATR',
    'footer.disclaimer': 'Yatırım tavsiyesi değildir.',
    'footer.risk': 'Her zaman riski uygun şekilde yönetin.',
    'language.toggle': 'Dil',
    'loading': 'Yükleniyor...',
    'error': 'Veri yüklenirken hata oluştu',
    'noResults': 'Sonuç bulunamadı',
    'refresh': 'Yenile',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('language') as Language | null;
      return saved || 'en';
    }
    return 'en';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('language', lang);
    }
  };

  const t = (key: string): string => {
    return translations[language]?.[key] || translations['en'][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}
