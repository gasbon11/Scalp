import { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Search, RefreshCw } from 'lucide-react';
import SignalDisplay from '@/components/SignalDisplay';
import TPSLDisplay from '@/components/TPSLDisplay';

type Exchange = 'okx' | 'mexc' | 'bitget';

const COUNTDOWN_SECONDS = 90; // 1:30

/**
 * Geri sayım sayacı hook'u
 * Her token satırı için bağımsız çalışır
 */
function useCountdown(onExpire: () => void) {
  const [seconds, setSeconds] = useState(COUNTDOWN_SECONDS);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const reset = useCallback(() => {
    setSeconds(COUNTDOWN_SECONDS);
  }, []);

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      setSeconds((prev) => {
        if (prev <= 1) {
          onExpire();
          return COUNTDOWN_SECONDS;
        }
        return prev - 1;
      });
    }, 1000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [onExpire]);

  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  const label = `${minutes}:${secs.toString().padStart(2, '0')}`;

  return { label, reset };
}

/**
 * Token başlığı — isim, sayaç, yenileme ikonu, canlı fiyat
 */
function TokenHeader({
  symbol,
  exchange,
  currentPrice,
  priceChange,
  isLoadingTicker,
  onRefresh,
}: {
  symbol: string;
  exchange: Exchange;
  currentPrice: number | null;
  priceChange: number | null;
  isLoadingTicker: boolean;
  onRefresh: () => void;
}) {
  const { t } = useLanguage();
  const { label: countdownLabel, reset: resetCountdown } = useCountdown(onRefresh);

  const handleRefreshClick = () => {
    resetCountdown();
    onRefresh();
  };

  const formatPrice = (price: number): string => {
    if (!price) return '0';
    if (price >= 1000) return price.toFixed(2);
    if (price >= 1) return price.toFixed(4);
    if (price >= 0.01) return price.toFixed(6);
    return price.toFixed(8);
  };

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-2">
          {/* Token ismi + sayaç + yenileme ikonu */}
          <div className="flex items-center gap-2 flex-wrap">
            <CardTitle className="text-2xl text-foreground">{symbol}</CardTitle>
            {/* Sayaç */}
            <span className="text-sm font-mono text-muted-foreground bg-muted px-2 py-0.5 rounded">
              {countdownLabel}
            </span>
            {/* Yenileme ikonu */}
            <button
              onClick={handleRefreshClick}
              title={t('refresh')}
              className="text-muted-foreground hover:text-accent transition-colors"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>
          {isLoadingTicker && <Loader2 className="h-5 w-5 animate-spin text-accent" />}
        </div>
        <p className="text-sm text-muted-foreground">{exchange.toUpperCase()} • FUTURES</p>
      </CardHeader>
      <CardContent>
        {currentPrice !== null && (
          <div className="flex items-end gap-6 flex-wrap">
            {/* Canlı fiyat — sayaçtan bağımsız, saniyelik akar */}
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">{t('price.current')}</p>
              <p className="text-2xl font-bold text-foreground font-mono">
                {formatPrice(currentPrice)}
              </p>
            </div>
            {/* 24h Change */}
            {priceChange !== null && (
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">24h Change</p>
                <p
                  className={`text-lg font-semibold ${
                    priceChange >= 0 ? 'text-accent' : 'text-destructive'
                  }`}
                >
                  {priceChange >= 0 ? '+' : ''}
                  {priceChange.toFixed(2)}%
                </p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function Analyzer() {
  const { language, setLanguage, t } = useLanguage();
  const [exchange, setExchange] = useState<Exchange>('okx');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSymbol, setSelectedSymbol] = useState<string | null>(null);
  // Sinyal yenileme için manuel tetikleyici
  const [signalRefreshKey, setSignalRefreshKey] = useState(0);

  const exchanges: Exchange[] = ['okx', 'mexc', 'bitget'];

  // Sistem sadece futures baz alır
  const marketMode = 'futures' as const;

  // Search markets
  const searchQuery = trpc.market.searchMarkets.useQuery(
    {
      exchange,
      marketMode,
      searchTerm: searchTerm.toUpperCase(),
    },
    {
      enabled: searchTerm.length > 0,
      staleTime: 30000,
    }
  );

  // Get signal for selected symbol
  const signalQuery = trpc.analysis.getSignal.useQuery(
    {
      exchange,
      symbol: selectedSymbol || '',
    },
    {
      enabled: !!selectedSymbol,
      staleTime: 5000,
      refetchInterval: 5000,
    }
  );

  // Get ticker for selected symbol — canlı fiyat, saniyelik yenilenir
  const tickerQuery = trpc.market.getTicker.useQuery(
    {
      exchange,
      symbol: selectedSymbol || '',
    },
    {
      enabled: !!selectedSymbol,
      staleTime: 1000,
      refetchInterval: 2000, // 2 saniyede bir canlı fiyat
    }
  );

  const searchResults = useMemo(() => {
    return searchQuery.data || [];
  }, [searchQuery.data]);

  // Sayaç dolunca veya yenile ikonuna tıklanınca sadece bu token'ın verisini yenile
  const handleRefresh = useCallback(() => {
    signalQuery.refetch();
  }, [signalQuery]);

  const currentPrice = tickerQuery.data?.last ?? null;
  const priceChange = tickerQuery.data?.percentage ?? null;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-accent">{t('app.title')}</h1>
              <p className="text-sm text-muted-foreground">{t('app.subtitle')}</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setLanguage(language === 'en' ? 'tr' : 'en')}
              className="gap-2"
            >
              {language === 'en' ? '🇹🇷 TR' : '🇬🇧 EN'}
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Controls */}
        <div className="mb-8 space-y-4">
          {/* Exchange Selector */}
          <div>
            <label className="mb-2 block text-sm font-medium">{t('exchange.select')}</label>
            <div className="flex gap-2 flex-wrap">
              {exchanges.map((ex) => (
                <Button
                  key={ex}
                  variant={exchange === ex ? 'default' : 'outline'}
                  onClick={() => {
                    setExchange(ex);
                    setSelectedSymbol(null);
                    setSearchTerm('');
                  }}
                  className="uppercase"
                >
                  {t(`exchange.${ex}`)}
                </Button>
              ))}
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder={t('search.placeholder')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-input text-foreground placeholder:text-muted-foreground"
              />
            </div>

            {/* Search Results Dropdown */}
            {searchTerm && (
              <div className="absolute top-full left-0 right-0 mt-2 max-h-64 overflow-y-auto rounded-lg border border-border bg-card shadow-lg z-10">
                {searchQuery.isLoading && (
                  <div className="flex items-center justify-center gap-2 p-4">
                    <Loader2 className="h-4 w-4 animate-spin text-accent" />
                    <span className="text-sm text-muted-foreground">{t('loading')}</span>
                  </div>
                )}
                {searchQuery.error && (
                  <div className="p-4 text-sm text-destructive">{t('error')}</div>
                )}
                {searchResults.length === 0 && !searchQuery.isLoading && (
                  <div className="p-4 text-sm text-muted-foreground">{t('noResults')}</div>
                )}
                {searchResults.map((market) => (
                  <button
                    key={market.symbol}
                    onClick={() => {
                      setSelectedSymbol(market.symbol);
                      setSearchTerm('');
                    }}
                    className="w-full px-4 py-3 text-left hover:bg-muted transition-colors border-b border-border last:border-b-0"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-foreground">{market.symbol}</div>
                        <div className="text-xs text-muted-foreground">
                          {market.baseAsset}/{market.quoteAsset}
                        </div>
                      </div>
                      <Badge variant="secondary">{market.quoteAsset}</Badge>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Selected Symbol Analysis */}
        {selectedSymbol && (
          <div className="space-y-6">
            {/* Token Header — sayaç + yenileme + canlı fiyat */}
            <TokenHeader
              symbol={selectedSymbol}
              exchange={exchange}
              currentPrice={currentPrice}
              priceChange={priceChange}
              isLoadingTicker={tickerQuery.isLoading}
              onRefresh={handleRefresh}
            />

            {/* Signal Analysis */}
            {signalQuery.isLoading && (
              <Card className="bg-card border-border">
                <CardContent className="flex items-center justify-center gap-2 py-8">
                  <Loader2 className="h-5 w-5 animate-spin text-accent" />
                  <span className="text-muted-foreground">{t('loading')}</span>
                </CardContent>
              </Card>
            )}

            {signalQuery.data && <SignalDisplay data={signalQuery.data} />}
          </div>
        )}

        {/* Empty State */}
        {!selectedSymbol && (
          <Card className="bg-card border-border">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <Search className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg font-semibold text-foreground mb-2">{t('search.results')}</p>
              <p className="text-sm text-muted-foreground text-center max-w-md">
                Search for a token above to start analyzing real-time trading signals
              </p>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-background/50 py-6 mt-12">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>
            {language === 'tr'
              ? 'TR: Yatırım tavsiyesi değildir.'
              : 'EN: Not financial advice.'}
          </p>
          <p className="mt-1">{t('footer.risk')}</p>
        </div>
      </footer>
    </div>
  );
}
